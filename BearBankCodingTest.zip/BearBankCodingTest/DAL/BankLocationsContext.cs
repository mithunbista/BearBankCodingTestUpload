namespace BearBankCodingTest.DAL
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class BankLocationsContext : DbContext
    {
        public BankLocationsContext()
            : base("name=BankLocationsContext")
        {
        }

        public virtual DbSet<BankLocation> BankLocations { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BankLocation>()
                .Property(e => e.Location)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.Status)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.Address1)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.Address2)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.City)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.State)
                .IsUnicode(false);

            modelBuilder.Entity<BankLocation>()
                .Property(e => e.ZipCode)
                .IsUnicode(false);
        }
    }
}
