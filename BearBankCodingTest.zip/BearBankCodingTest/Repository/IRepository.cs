﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BearBankCodingTest.Repository
{
    public interface IRepository<TEntity, in TKey> where TEntity : class
    {
        TEntity Get(TKey Id);
        Task<TEntity> GetAsync(TKey Id);

        Task<bool> SaveAsync(TEntity entity);
        bool Save(TEntity entity);

        Task<bool> UpdateAsync(TEntity entity);
        bool Update(TEntity entity);

        Task<bool> DeleteAsync(TEntity entity);
        bool Delete(TEntity entity);
    }
}
