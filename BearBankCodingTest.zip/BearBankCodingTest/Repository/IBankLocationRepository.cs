﻿namespace BearBankCodingTest.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using BearBankCodingTest.DAL;

    interface IBankLocationRepository : IRepository<BankLocation, String>, IDisposable
    {
        IEnumerable<BankLocation> FindAll();
        Task<BankLocation> FindAsync<T>(T Id);
        BankLocation Find<T>(T Id);
        IEnumerable<BankLocation> FindAllValid();
    }
}
