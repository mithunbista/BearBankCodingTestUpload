﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using BearBankCodingTest.DAL;

namespace BearBankCodingTest.Repository
{
    public class BankLocationRepository : IBankLocationRepository
    {
        private readonly BankLocationsContext _dbContext;

        public BankLocationRepository(BankLocationsContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// Async Find Bank Location By Id
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<BankLocation> FindAsync<T>(T Id) 
        {
            var bankLocation = new BankLocation();
            bankLocation = await _dbContext.BankLocations.FindAsync(Id);
            return bankLocation;
        }

        /// <summary>
        /// Sync Find Bank Locations By Id
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Id"></param>
        /// <returns></returns>
        public BankLocation Find<T>(T Id)
        {
            var bankLocation = new BankLocation();
            bankLocation = _dbContext.BankLocations.Find(Id);
            return bankLocation; 
        }

        /// <summary>
        /// Find All BankLocations
        /// </summary>
        /// <returns></returns>
        public IEnumerable<BankLocation> FindAll()
        {
            return _dbContext.BankLocations.Count() > 0 ? _dbContext.BankLocations.ToList() : new List<BankLocation>();
        }

        /// <summary>
        /// Find All Valid Bank Locations
        /// </summary>
        /// <returns></returns>
        public IEnumerable<BankLocation> FindAllValid()
        {
            var rtnBankLocations = new List<BankLocation>();

            rtnBankLocations = _dbContext.BankLocations.Where(x => !String.IsNullOrEmpty(x.Address1) &&
            !String.IsNullOrEmpty(x.City) && !String.IsNullOrEmpty(x.State) && !String.IsNullOrEmpty(x.ZipCode)).ToList();

            return rtnBankLocations;
        }

        /// <summary>
        /// Aysnc Get
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<BankLocation> GetAsync(string Id)
        {
            var bankLocation = new BankLocation();
            bankLocation = await _dbContext.BankLocations.FindAsync(Id);
            return bankLocation;
        }

        /// <summary>
        /// Sync Get
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public BankLocation Get(string Id)
        {
            var bankLocation = new BankLocation();
            bankLocation = _dbContext.BankLocations.Find(Id);
            return bankLocation;
        }

        /// <summary>
        /// Async Save or Create
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> SaveAsync(BankLocation entity)
        {
            if (entity == null) return false;

            _dbContext.BankLocations.Add(entity);
            return await _dbContext.SaveChangesAsync() > 0;
        }

        /// <summary>
        /// Sync Save or Create
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool Save(BankLocation entity)
        {
            if(entity == null) return false;

            _dbContext.BankLocations.Add(entity);
            return _dbContext.SaveChanges() > 0;
        }

        /// <summary>
        /// Async Update
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> UpdateAsync(BankLocation entity)
        {
            if (entity == null) return false;

            _dbContext.Entry(entity).State = System.Data.Entity.EntityState.Modified;
            return await _dbContext.SaveChangesAsync() > 0;
        }

        public bool Update(BankLocation entity)
        {
            if(entity == null) return false;

            _dbContext.Entry(entity).State = System.Data.Entity.EntityState.Modified;
            return _dbContext.SaveChanges() > 0;
        }

        /// <summary>
        /// Async delete
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> DeleteAsync(BankLocation entity)
        {
            if (entity == null) return false;

            _dbContext.BankLocations.Remove(entity);
            return await _dbContext.SaveChangesAsync() > 0;
        }

        /// <summary>
        /// Sync delete
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool Delete(BankLocation entity)
        {
            if (entity == null) return false;

            _dbContext.BankLocations.Remove(entity);
            return _dbContext.SaveChanges() > 0;
        }

        /// <summary>
        /// Check to see if a bank location exists
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool BankLocationExists(int id)
        {
            if (id <= 0) return false;

            return _dbContext.BankLocations.Count(e => e.Id == id) > 0;
        }

        /// <summary>
        /// Dipose method
        /// </summary>
        public void Dispose()
        {
            if (_dbContext != null)
                _dbContext.Dispose();
        }
    }
}