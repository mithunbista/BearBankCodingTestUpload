﻿namespace BearBankCodingTest.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Entity;
    using System.Data.Entity.Infrastructure;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Threading.Tasks;
    using System.Web.Http;
    using System.Web.Http.Description;
    using BearBankCodingTest.DAL;
    using BearBankCodingTest.Repository;

    public class BankLocationsController : ApiController
    {
        private readonly BankLocationRepository bankLocationRepository = new BankLocationRepository(new BankLocationsContext());

        /// <summary>
        /// Get all bank locations that are valid
        /// Used Repository Pattern
        /// Please check the Repository folder for this design pattern
        /// Also used Async Await pattern
        /// </summary>
        /// <returns></returns>
        // GET: api/BankLocations
        public IEnumerable<BankLocation> GetBankLocations()
        {
            return bankLocationRepository.FindAllValid();
        }

        /// <summary>
        /// Get a single bank location using id in async way
        /// Used Repository Pattern
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // GET: api/BankLocations/5
        [ResponseType(typeof(BankLocation))]
        public async Task<IHttpActionResult> GetBankLocation(int id)
        {
            if(id <= 0) return NotFound();

            BankLocation bankLocation = await bankLocationRepository.FindAsync<int>(id);

            if (bankLocation == null) return NotFound();
     
            return Ok(bankLocation);
        }

        /// <summary>
        /// Update bank location using PUT verb in async way
        /// Used Repository Pattern
        /// </summary>
        /// <param name="id"></param>
        /// <param name="bankLocation"></param>
        /// <returns></returns>
        // PUT: api/BankLocations/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutBankLocation(int id, BankLocation bankLocation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != bankLocation.Id)
            {
                return BadRequest();
            }

            try
            {
                await bankLocationRepository.UpdateAsync(bankLocation);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BankLocationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        /// <summary>
        /// Create a new bank location using POST verb
        /// </summary>
        /// <param name="bankLocation"></param>
        /// <returns></returns>
        // POST: api/BankLocations
        [ResponseType(typeof(BankLocation))]
        public async Task<IHttpActionResult> PostBankLocation(BankLocation bankLocation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            await bankLocationRepository.SaveAsync(bankLocation);

            return CreatedAtRoute("BankLocationApi", new { id = bankLocation.Id }, bankLocation);
        }

        /// <summary>
        /// Delete a banklocation using DELETE verb
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        // DELETE: api/BankLocations/5
        [ResponseType(typeof(BankLocation))]
        public async Task<IHttpActionResult> DeleteBankLocation(int id)
        {
            var bankLocation = await bankLocationRepository.FindAsync(id);

            if (bankLocation == null)
            {
                return NotFound();
            }

            await bankLocationRepository.DeleteAsync(bankLocation);

            return Ok(bankLocation);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                bankLocationRepository.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Check to see if bank location exists
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool BankLocationExists(int id)
        {
            return bankLocationRepository.BankLocationExists(id);
        }
    }
}